from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Sede(models.Model):
    departamento=models.CharField(max_length=50)
    provincia=models.CharField(max_length=50)
    distrito=models.CharField(max_length=50)
    direccion=models.CharField(max_length=50)
    
    class Meta:
        db_table='Sede'

class Docente(models.Model):

    nombre=models.CharField(max_length=50)
    apellido=models.CharField(max_length=50)
    edad=models.IntegerField()
    dni=models.IntegerField()
    correo=models.CharField(max_length=50)
    direccion=models.CharField(max_length=50)
    fecha_nacimiento=models.DateField()
    grado_cinturon=models.CharField(max_length=50)
    foto_perfil= models.ImageField(upload_to='imagenes_bd/',null=True,blank=True)
    genero=models.CharField(max_length=10,default='sin genero')
    id_usuario=models.ForeignKey(User,on_delete=models.CASCADE)

    class Meta:
        db_table='Docente'
 

class SedeUsuario(models.Model):
    usuario=models.ForeignKey(User,on_delete=models.CASCADE)
    sede=models.ForeignKey(Sede,on_delete=models.CASCADE)
    class Meta:
        db_table='SedeUsuario'