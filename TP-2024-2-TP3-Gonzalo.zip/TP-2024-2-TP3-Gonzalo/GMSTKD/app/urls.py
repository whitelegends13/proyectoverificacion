from django.urls import path
from .views import landing_page ,login,dashboard,sedes,usuarios,docentes

urlpatterns = [

    path('',landing_page.clase_gratis_landing,name='clase_gratis_landing'),
    path('login_admin/',login.login_admin,name='login_admin'),
    path('login/',login.login_docente,name='login'),
    path('logout/',login.logout,name='logout'),
    path('dashboard_admin/',dashboard.dashboard_admin,name='dashboard_admin'),
    path('dashboard_docente/',dashboard.dashborad_docente,name='dashboard_docente'),

    #Sedes
    path('lista_sedes/',sedes.lista_sedes,name='lista_sedes'),
    path('registrar_sede/',sedes.registrar_sede,name='registrar_sede'),
    path('editar_sedes/<int:id_sede>',sedes.editar_sedes,name='editar_sedes'),
    path('detalles_sede/<int:id_sede>',sedes.detalles_sede,name='detalles_sede'),
    path('eliminar_sede/<int:id_sede>',sedes.eliminar_sede,name='eliminar_sede'),

    #Filtros Sede
    path('buscar_sedes/', sedes.filtros_columnas, name='buscar_sedes'),

    #Usuarios
    path('lista_usuarios/',usuarios.listaUsuarios,name='lista_usuarios'),
    path('registrar_usuario/',usuarios.add_usuario,name='registrar_usuario'),
    path('detalles_usuario/<int:id_usuario>',usuarios.detalles_usuario,name='detalles_usuario'),
    path('editar_usuario/<int:id_usuario>',usuarios.editar_usuario,name='editar_usuario'),
    path('eliminar_usuario/<int:id_usuario>',usuarios.eliminar_usuario,name='eliminar_usuario'),
    #Filtro Usuarios
    path('buscar_usuarios/',usuarios.filtros_columnas,name='buscar_usuarios'),

    path('lista_docentes/',docentes.lista_docentes,name='lista_docentes'),
    path('registrar_docente/',docentes.registrar_docente,name='registrar_docente'),
    path('editar_docente/<int:id_docente>',docentes.editar_docente,name='editar_docente'),
    path('detalles_docente/<int:id_docente>',docentes.detalle_docente,name='detalles_docente'),  
    path('eliminar_docente/<int:id_docente>',docentes.eliminar_docente,name='eliminar_docente'),

    #Filtro Docentes
    path('buscar_docentes/',docentes.filtros_columnas,name='buscar_docentes'),
    path('buscar_cinta',docentes.filtro_cinta,name='filtro_cinta'),

]


