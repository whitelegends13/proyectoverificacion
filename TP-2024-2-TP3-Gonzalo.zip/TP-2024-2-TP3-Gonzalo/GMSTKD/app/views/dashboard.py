from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from app.models import SedeUsuario,Docente


def dashboard_admin(request):
    user = request.user
    return render(request,'app/dashboard/dashboard_admin.html',{'user': user})

def dashborad_docente(request):
    user= request.user
    sedeUsuario= SedeUsuario.objects.get(usuario=user)
    docente=Docente.objects.get(id_usuario=user)
    contexto={'sedeUsuario':sedeUsuario,'user':user,'docente':docente}
    return render(request,'app/dashboard/dashboard_docente.html',contexto)