from django.shortcuts import render

def clase_gratis_landing(request):
    return render(request,'app/landing/clase_gratis.html')

