from django.shortcuts import render,redirect
from django.contrib import messages
from app.models import Sede
from django.db.models import Q

def lista_sedes(request):
    sedes= Sede.objects.all()
    contexto ={'sedes':sedes}
    return render(request,'app/sedes/lista_sedes.html',contexto)

def editar_sedes(request,id_sede):
    sede= Sede.objects.get(id=id_sede)
    if request.method=='POST':
        sede.departamento = request.POST.get('departamento')
        sede.provincia = request.POST.get('provincia')
        sede.distrito = request.POST.get('distrito')
        sede.direccion = request.POST.get('direccion')
        
        # Guardar los cambios en la base de datos

        sede.save()
        messages.success(request,'Editado con exito')
        return redirect('editar_sedes', id_sede=sede.id)
    else:
        return render(request,'app/sedes/editar_sede.html',{'sede':sede})
    
def registrar_sede(request):

    if request.method=='POST':
        departamento = request.POST.get('departamento')
        provincia = request.POST.get('provincia')
        distrito = request.POST.get('distrito')
        direccion = request.POST.get('direccion')
        sede=Sede(departamento=departamento,provincia=provincia,distrito=distrito,direccion=direccion)
        sede.save()
        messages.success(request, "Registrado con exito")

        return render(request,'app/sedes/registrar_sede.html')
    else:
        return render(request,'app/sedes/registrar_sede.html')

def detalles_sede(request,id_sede):
    sede=Sede.objects.get(id=id_sede)
    return render(request,'app/sedes/detalles_sede.html',{'sede':sede})

def eliminar_sede(request,id_sede):
    sede=Sede.objects.get(id=id_sede)
    sede.delete()
    return redirect('lista_sedes')

def filtros_columnas(request):
    query = request.GET.get('q')
    if query:
        sedes=Sede.objects.filter(
            Q(departamento__icontains=query)|
            Q(provincia__icontains=query) | 
            Q(distrito__icontains=query) | 
            Q(direccion__icontains=query)
        )
    else:
        sedes=Sede.objects.all()
    contexto={'sedes':sedes,'query':query}
    return render(request,'app/sedes/lista_sedes.html',contexto)
