from django.shortcuts import render,redirect
from django.contrib import messages
from app.models import Docente
from app.models import Sede
from django.contrib.auth.models import User
from django.db.models import Q


def lista_docentes(request):
    docentes=Docente.objects.all()
    return render(request,'app/docentes/lista_docentes.html',{'docentes':docentes})

def registrar_docente(request):
    if request.method=='POST':
        nombre=request.POST.get('nombre')
        apellido=request.POST.get('apellido')
        edad=int(request.POST.get('edad'))
        dni=int(request.POST.get('dni'))
        correo=request.POST.get('correo')
        direccion=request.POST.get('direccion')
        fecha_nacimiento=request.POST.get('fecha_nacimiento')
        grado_cinturon=request.POST.get('grado_cinturon')
        foto_perfil=request.FILES.get('foto_perfil')
        genero=request.POST.get('genero')
        usuario=int(request.POST.get('usuario'))
       
        user_instance = User.objects.get(pk=usuario)
        
       
        

        docente = Docente(
        nombre=nombre,
        apellido=apellido,
        edad=edad,
        dni=dni,
        correo=correo,
        direccion=direccion,
        fecha_nacimiento=fecha_nacimiento,
        grado_cinturon=grado_cinturon,
        foto_perfil=foto_perfil,
        genero=genero,
        id_usuario=user_instance,
        )
        docente.save()
        messages.success(request,'Docente Registrado con exito')
        return render(request,'app/docentes/registrar_docente.html')
    else: 
        usuarios = User.objects.filter(is_superuser=False,docente__isnull=True)
        contexto={'usuarios':usuarios}
        return render(request,'app/docentes/registrar_docente.html',contexto)
    
def editar_docente(request, id_docente):
    docente = Docente.objects.get(id=id_docente)
    if request.method == 'POST':
        docente.nombre = request.POST.get('nombre')
        docente.apellido = request.POST.get('apellido')
        docente.edad = int(request.POST.get('edad'))
        docente.dni = int(request.POST.get('dni'))
        docente.correo = request.POST.get('correo')
        docente.direccion = request.POST.get('direccion')
        docente.fecha_nacimiento = request.POST.get('fecha_nacimiento')
        docente.grado_cinturon = request.POST.get('grado_cinturon')

        # Manejo de la foto de perfil
        if 'foto_perfil' in request.FILES:
            docente.foto_perfil = request.FILES['foto_perfil']
        
        docente.genero = request.POST.get('genero')
        usuario = int(request.POST.get('usuario'))
        user_instance = User.objects.get(pk=usuario)
        docente.id_usuario = user_instance

        docente.save()
        messages.success(request, 'Docente editado con éxito')
        return redirect('editar_docente', docente.id)
    else:
        usuarios = User.objects.filter(is_superuser=False, docente__isnull=True)
        docente = Docente.objects.get(id=id_docente)
        contexto = {'usuarios': usuarios, 'docente': docente}
        return render(request, 'app/docentes/editar_docente.html', contexto)

def detalle_docente(request, id_docente):
    docente = Docente.objects.get(id=id_docente)
    return render(request, 'app/docentes/detalle_docente.html', {'docente':docente})

def eliminar_docente(request,id_docente):
    docente=Docente.objects.get(id=id_docente)
    docente.delete()
    return redirect('lista_docentes')

def filtros_columnas(request):
    query = request.GET.get('q')
    if query:
        docentes=Docente.objects.filter(
            Q(id__icontains=query)|
            Q(dni__icontains=query) | 
            Q(nombre__icontains=query) | 
            Q(grado_cinturon__icontains=query)
        )
    else:
        docentes=Docente.objects.all()
    contexto={'docentes':docentes,'query':query}
    return render(request,'app/docentes/lista_docentes.html',contexto)

def filtro_cinta(request):
    query=request.GET.get('q')
    if query:
        docentes=Docente.objects.filter(grado_cinturon__contains=query)
    else:
        docentes=Docente.objects.all()
        contexto={'docentes':docentes,'query':query}
        return render(request,'app/docentes/lista_docentes.html',contexto)

