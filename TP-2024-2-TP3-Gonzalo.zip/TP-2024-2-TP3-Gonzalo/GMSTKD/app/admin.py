from django.contrib import admin
from .models import Docente,Sede
# Register your models here.

admin.site.register(Docente)
admin.site.register(Sede)
